# QA Genie

This is a package for generating questions and answers from unstructured data to be used for NLP tasks.

Built using hugchat (HuggingChat's unofficial API).